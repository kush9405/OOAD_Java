// view.h
#ifndef VIEW_H
#define VIEW_H

#include "model.h"
#include <iostream>

class EmployeeView {
public:
    void displayEmployeeDetails(const Employee &emp);
};

#endif
