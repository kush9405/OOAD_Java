Compile
-------
g++ -o server main.cpp model.cpp view.cpp controller.cpp -std=c++17 -lpthread

********************************************************************************************************

Run
----
./server

********************************************************************************************************

Test the Web Application
-------------------------
Open a browser and visit: http://localhost:8080/employee
You will see an HTML page displaying employee details.

********************************************************************************************************

