Deploying the Application
--------------------------
1. Compile the Java Classes: Make sure you compile all your Java files and place them in the correct directory structure (e.g., WEB-INF/classes).
2. JSP Files: Place your JSP files under the WebContent or webapp directory.
3. Web Server: Deploy the application to a servlet container like Apache Tomcat.


******************************************************************************************************************


Testing the Application
-----------------------
1. Open the browser and go to http://localhost:8080/your-webapp/EmployeeController?action=view to see the employee list.
2. To add a new employee, fill in the form and submit it.