// View Class
public class EmployeeView {
    public void printEmployeeDetails(int id, String name, double salary) {
        System.out.println("Employee Details:");
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Salary: $" + salary);
    }
}
